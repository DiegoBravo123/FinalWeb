package pe.edu.upc.service;

import pe.edu.upc.entity.Cliente;

public interface IClienteService {
	public Integer insertar(Cliente cliente);

	public Cliente findByUsername(String username);

}
