package pe.edu.upc.service;

import pe.edu.upc.entity.Admin;

public interface IAdminService {
	
	public Integer insertar(Admin admin);

}
