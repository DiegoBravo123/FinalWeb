package pe.edu.upc.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.edu.upc.entity.Cliente;
import pe.edu.upc.repository.IClienteRepository;
import pe.edu.upc.service.IClienteService;

@Service
public class ClienteServiceImpl implements IClienteService {

	@Autowired
	private IClienteRepository cR;

	@Override
	@Transactional
	public Integer insertar(Cliente cliente) {
		// TODO Auto-generated method stub
		int rpta = 0;
		if (rpta == 0) {
			cR.save(cliente);
		}
		return rpta;
	}

	@Override
	@Transactional(readOnly = true)
	public Cliente findByUsername(String username) {
		// TODO Auto-generated method stub
		return cR.findByUsername(username);
	}

}
