package pe.edu.upc.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.edu.upc.entity.Mecanico;
import pe.edu.upc.repository.IMecanicoRepository;
import pe.edu.upc.service.IMecanicoService;

@Service
public class MecanicoServiceImpl implements IMecanicoService {

	@Autowired
	private IMecanicoRepository mR;

	@Override
	@Transactional
	public Integer insertar(Mecanico mecanico) {
		// TODO Auto-generated method stub
		int rpta = 0;
		if (rpta == 0) {
			mR.save(mecanico);
		}
		return rpta;
	}

	@Override
	@Transactional(readOnly = true)
	public Mecanico findByUsername(String username) {
		// TODO Auto-generated method stub
		return mR.findByUsername(username);
	}

}
