package pe.edu.upc.service;

import pe.edu.upc.entity.Mecanico;

public interface IMecanicoService {
	public Integer insertar(Mecanico mecanico);

	public Mecanico findByUsername(String username);
}
