package pe.edu.upc;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit4.SpringRunner;

import pe.edu.upc.entity.Mecanico;
import pe.edu.upc.service.IMecanicoService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AgregarMecanico {

	private IMecanicoService mS;

	@Autowired
	private BCryptPasswordEncoder encoder;

	@Test
	public void crearUsuarioTest() {

		Mecanico mecanico = new Mecanico();
		mecanico.setId(3);
		mecanico.setNombreUsuario("meko");
		mecanico.setDniUsuario("76897096");
		mecanico.setEmailUsuario("meko@hotmail.com");
		mecanico.setFechaNacimientoUsuario(null);
		mecanico.setTelefonoUsuario("978978789");
		mecanico.setFoto("xd");
		mecanico.setUsername("meko");
		mecanico.setPassword(encoder.encode("meko"));

		mS.insertar(mecanico);

	}
}
