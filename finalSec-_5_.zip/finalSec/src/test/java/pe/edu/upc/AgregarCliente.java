package pe.edu.upc;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit4.SpringRunner;

import pe.edu.upc.entity.Cliente;
import pe.edu.upc.service.IClienteService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class AgregarCliente {

	@Autowired
	private IClienteService cS;

	@Autowired
	private BCryptPasswordEncoder encoder;

	@Test
	public void crearUsuarioTest() {

		Cliente cliente = new Cliente();
		cliente.setId(2);
		cliente.setNombreUsuario("gugu");
		cliente.setDniUsuario("76897096");
		cliente.setEmailUsuario("gugu@hotmail.com");
		cliente.setFechaNacimientoUsuario(null);
		cliente.setTelefonoUsuario("978978789");
		cliente.setFoto("xd");
		cliente.setUsername("gugu");
		cliente.setPassword(encoder.encode("gugu"));

		cS.insertar(cliente);

	}
}
