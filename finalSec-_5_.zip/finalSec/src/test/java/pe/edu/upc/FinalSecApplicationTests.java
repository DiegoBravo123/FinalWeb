package pe.edu.upc;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.test.context.junit4.SpringRunner;

import pe.edu.upc.entity.Cliente;
import pe.edu.upc.entity.Vehiculo;
import pe.edu.upc.repository.IClienteRepository;
import pe.edu.upc.service.IClienteService;
import pe.edu.upc.service.IVehiculoService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class FinalSecApplicationTests {

	@Autowired
	private IClienteRepository cR;

	@Autowired
	private IVehiculoService vS;

	@Autowired
	private IClienteService cS;

	@Autowired
	private BCryptPasswordEncoder encoder;

	@Test
	public void crearUsuarioTest() {

		Cliente cliente = new Cliente();
		cliente.setId(1);
		cliente.setNombreUsuario("pepe");
		cliente.setDniUsuario("76897096");
		cliente.setEmailUsuario("pepe@hotmail.com");
		cliente.setFechaNacimientoUsuario(null);
		cliente.setTelefonoUsuario("978978789");
		cliente.setFoto("xd");
		cliente.setUsername("qwerty");
		cliente.setPassword(encoder.encode("qwerty"));

		cS.insertar(cliente);

		Vehiculo vehiculo = new Vehiculo();
		vehiculo.setDescripcionVehiculo("xd");
		vehiculo.setPlacaVehiculo("lol");
		vehiculo.setFotoVehiculo("omg");
		vehiculo.setCliente(cR.findByUsername("qwerty"));

		vS.insertar(vehiculo);

		// Usuario retorno = uR.save(usuario);
		// assertTrue(retorno.getPassword().equalsIgnoreCase(usuario.getPassword()));

	}

}
