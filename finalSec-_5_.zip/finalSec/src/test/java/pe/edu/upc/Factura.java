package pe.edu.upc;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import pe.edu.upc.entity.FacturaServicio;
import pe.edu.upc.entity.Servicio;
import pe.edu.upc.service.IClienteService;
import pe.edu.upc.service.IEstadoServicioService;
import pe.edu.upc.service.IFacturaServicioService;
import pe.edu.upc.service.IMecanicoService;
import pe.edu.upc.service.ISedeService;
import pe.edu.upc.service.IServicioService;
import pe.edu.upc.service.ITipoServicioService;
import pe.edu.upc.service.IVehiculoService;

@RunWith(SpringRunner.class)
@SpringBootTest
public class Factura {

	@Autowired
	private IFacturaServicioService fsS;

	@Autowired
	private IEstadoServicioService esS;

	@Autowired
	private IMecanicoService mS;

	@Autowired
	private ISedeService sS;

	@Autowired
	private ITipoServicioService tsS;

	@Autowired
	private IVehiculoService vS;

	@Autowired
	private IClienteService cS;

	@Autowired
	private IServicioService serS;

	@Test
	public void crearUsuarioTest() {

		FacturaServicio factura = new FacturaServicio();
		factura.setFotoFactura("xd");
		factura.setMontoTotal(200);

		Servicio servicio = new Servicio();
		servicio.setDescripcionServicio("xd");
		servicio.setEstadoServicio(esS.list().get(0));
		servicio.setFechaServicio(null);
		servicio.setMecanico(mS.findByUsername("meca"));
		servicio.setSede(sS.list().get(0));
		servicio.setTipoServicio(tsS.list().get(0));
		servicio.setVehiculo(vS.list(cS.findByUsername("qwerty")).get(0));

		factura.setServicio(servicio);
		// servicio.setFactura(factura);

		// serS.insertar(servicio);
		fsS.insertar(factura);
	}
}
